create procedure exec_view2
as
begin
	select * from View_2
end