create view View_1 as
	select * from Antrenor
go
