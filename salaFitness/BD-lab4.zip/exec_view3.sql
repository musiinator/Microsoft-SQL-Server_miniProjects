create procedure exec_view3
as
begin
	select * from View_3
end